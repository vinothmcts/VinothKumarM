import React from 'react';
import ReactDOM from 'react-dom';


class Contact extends React.Component {
   render() {
      return (
         <div>
            <p>React-Team From WP005</p>
            <p>Cognizant</p>
         </div>
      )
   }
}

export default Contact;